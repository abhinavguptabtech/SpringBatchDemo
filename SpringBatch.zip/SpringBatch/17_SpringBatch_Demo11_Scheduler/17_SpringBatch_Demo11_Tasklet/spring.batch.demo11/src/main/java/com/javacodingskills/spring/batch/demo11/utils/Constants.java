package com.javacodingskills.spring.batch.demo11.utils;

public class Constants {

    public static final String FILE_NAME_CONTEXT_KEY = "fileName";
    public static final String FILE_PATH_EMPCSV = "/Users/shiva.vadloori/Documents/SpringBatch/17_SpringBatch_Demo11_Tasklet/spring.batch.demo11/src/main/resources/employees.csv";
}
