package com.javacodingskills.spring.batch.demo4.utils;

public class Constants {

    public static final String FILE_NAME_CONTEXT_KEY = "fileName";
}
